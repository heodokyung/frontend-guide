■ 호스트설정

C:\Windows\System32\drivers\etc\hosts 파일에서 아래와 같이 추가하고 저장



########## CJ The Market Develop S ##########

10.64.0.134 devm.cjonmart.net

10.64.0.134 dev.cjonmart.net

10.64.0.134 devm.kitchen1953.net

10.64.0.134 dev.kitchen1953.net

10.64.0.134 devbo.cjonmart.net

10.64.0.134 devpo.cjonmart.net

10.64.0.134 publish.cjthemarket.com

10.64.0.134 publish.cjcookit.com

10.65.12.154 git.devops.cj.net

10.65.12.154 git.cj.cj.net

########## CJ The Market Develop E ##########



■ 퍼블리싱사이트

더마켓 http://publish.cjthemarket.com/index.html

쿡킷 http://publish.cjcookit.com/cjkit/web/index.html (거의 작업 없음....)


■ 디자인

디자인은 제플린사이트로 주시는경우도 있고 ... 파일첨부(메일 or 팀즈) 전송

제플린 사이트 https://app.zeplin.io/project/59fbc855c701aef03748ae11

                   아이디  simhn1210@gmail.com

                   비번 tlagksk1213!

