{% comment %}

아래의 link 는 이미지 클릭 시 이동하는 목적 URL 을 입력해주세요.

imgPath 는 인앱 팝업에 뜨는 이미지의 Full 경로를 입력해주세요.

isDeeplink 는 true/false 로 값을 설정해야 합니다. 

일반 웹URL 일 경우 false, 앱용 Deeplink 일 경우 true 를 설정하여 주세요.

{% endcomment %}

{% assign link1 = "cjthemarket://market_deeplink?url=
https://m.cjthemarket.com/mo/event/new/cjsalefesta?evntId=606129&inapp=TBRIAA"
%}

{% assign imgPath1 = "
https://braze-images.com/appboy/communication/assets/image_assets/images/667e457cbf1a12005a27840a/original.jpg?1719551355"
%}

{% assign isDeeplink1 = true %}

{% comment %}

{% assign link2 = "
https://daum.net"
%}

{% assign imgPath2 = "
https://braze-images.com/appboy/communication/assets/image_assets/images/619fbab367054f279a3f55ea/original.png?1637857970"
%}

{% assign isDeeplink2 = false %}

{% assign link3 = "
https://naver.com"
%}

{% assign imgPath3 = "
https://braze-images.com/appboy/communication/assets/image_assets/images/619fbab367054f279a3f55ea/original.png?1637857970"
%}

{% assign isDeeplink3 = false %}

{% endcomment %}

{% comment %}

아래의 코드는 개발자가 아니라면 수정하지 마십시오 

{% endcomment%}

{% assign linkArr1 = link1 | split : "?" %}

{% if linkArr1.size > 1 %}

{% assign delimiter1 = "&" %}

{% else %}

{% assign delimiter1 = "?" %}

{% endif %}

{% if isDeeplink1 == true %}

{% assign linkParam1 = delimiter1 | append : "abDeepLink=true" %}

{% else %}

{% assign linkParam1 = delimiter1 | append : "abExternalOpen=true" %}

{% endif %}

{% comment %}

{% assign linkArr2 = link2 | split : "?" %}

{% if linkArr2.size > 1 %}

{% assign delimiter2 = "&" %}

{% else %}

{% assign delimiter2 = "?" %}

{% endif %}

{% if isDeeplink2 == true %}

{% assign linkParam2 = delimiter2 | append : "abDeepLink=true" %}

{% else %}

{% assign linkParam2 = delimiter2 | append : "abExternalOpen=true" %}

{% endif %}

{% assign linkArr3 = link3 | split : "?" %}

{% if linkArr3.size > 1 %}

{% assign delimiter3 = "&" %}

{% else %}

{% assign delimiter3 = "?" %}

{% endif %}

{% if isDeeplink3 == true %}

{% assign linkParam3 = delimiter3 | append : "abDeepLink=true" %}

{% else %}

{% assign linkParam3 = delimiter3 | append : "abExternalOpen=true" %}

{% endif %}

{% endcomment %}

{% assign today = 'now' | date: '%s' | plus: 32400 | date: '%Y-%m-%d' %}

{% assign this_campaign = today | append: '_' | append: {{campaign.${message_api_id}}} %}

{% if {{custom_attribute.${팝업1일간보지않기_리스트}}} contains this_campaign %}

{% abort_message() %}

{% endif %}

<!DOCTYPE html>

<html lang="ko">

<head>

<meta charset="utf-8" />

<meta http-equiv="X-UA-Compatible" content="IE=Edge">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<title>title</title>

<link href="
https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700&family=Roboto:wght@300;400;500;700&display=swap"
rel="stylesheet" />

<script src="
https://code.jquery.com/jquery-3.5.0.min.js"></script>

<!-- <script type="text/javascript" src="
http://onchaedang.co.kr/share/js/jquery-1.11.3.min.js"></script>
-->

<script type="text/javascript" src="
http://onchaedang.co.kr/share/js/jquery.easing.1.3.js"></script>

<!--s slick css와 js-->

<link rel="stylesheet" type="text/css" href="
https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

<script type="text/javascript" src="
https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!--e slick css와 js-->

<style>

* {margin:0;padding:0;-webkit-text-size-adjust:none;}

*, *:before, *:after {box-sizing: inherit;}

/*링크*/

a{text-decoration:none;}

a:active {}

a:focus {}

a:visited, a:visited *, a.visited, a.visited:visited {text-decoration:none;}

a:hover,a:hover *,a.visited:hover {text-decoration:none;}

body {font-family:"Noto Sans KR", Malgun Gothic,'맑은 고딕',"돋움",Dotum,Verdana,Arial,helvetica,clean,sans-serif; color:#555; font-size:3.7vw; letter-spacing:-0.05em; line-height:1.5em; box-sizing: border-box}

select,input,button,textarea,button{font-family:"Noto Sans KR", 'Malgun Gothic','맑은 고딕',Dotum,Verdana;}

/*img*/

img {border:0px;vertical-align:middle;} 

/*팝업*/

#popup {position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.3)}

.popup_cont {position:absolute; bottom:0; left:0; width:100%; color:#fff}

/*슬라이드배너*/

.popup_sliderBox {position:relative;}

.popup_sliderBox .pagingInfo {position:absolute; top:3vw; right:3vw; background:rgba(0,0,0,0.3); padding:0.8vw 3.5vw; border-radius:50vw; font-size:3.4vw; z-index:10;}

.popup_slider .item img {width:100%}

.popup_slider .slick-dots li {display:none}

.popup_bottom {position:relative; background:#fff; padding:0 6.4vw; height:16.53vw; line-height:16.13vw; overflow:hidden}

.popcheck {float:left;}

.popcheck a {color:#333}

.popup_close {float:right;}

.popup_close a {color:#000; font-weight:700;}

</style>

</head>

<body>

<!--s #popup-->

<div id="popup" class="bodyFrame">

</div>

<!--e popup_cont-->

<!--s popup_cont-->

<div class="popup_cont clickArea">

       <!--s popup_img-->

       <!--s popup_sliderBox-->

       <div class="popup_sliderBox clickArea">

               <!-- <span class="pagingInfo clickArea"></span> -->

               <!--s popup_slider-->

               <div class="popup_slider clickArea">

                       <div class="item clickArea" onclick="javascript:appboyBridge.logClick('0');appboyBridge.requestImmediateDataFlush();document.location.href='{{link1}}{{linkParam1}}';"><img src="{{imgPath1}}"></div>

<!--                        <div class="item clickArea" onclick="javascript:appboyBridge.logClick('0');appboyBridge.requestImmediateDataFlush();document.location.href='{{link2}}{{linkParam2}}';"><img src="{{imgPath2}}"></div>

                       <div class="item clickArea" onclick="javascript:appboyBridge.logClick('0');appboyBridge.requestImmediateDataFlush();document.location.href='{{link3}}{{linkParam3}}';"><img src="{{imgPath3}}"></div>

-->

               </div>

               <!--e popup_slider-->

       </div>

       <!--e popup_sliderBox-->

       <!--e popup_img-->

       <!--s popup_bottom-->

       <div class="popup_bottom clickArea">

               <div class="popcheck clickArea"><a href="javascript:close_popup_1();">오늘 하루 보지 않기</a></div>

               <div class="popup_close clickArea"><a href="javascript:close_popup_2();">닫기</a></div>

       </div>

       <!--e popup_bottom-->

</div>

<!--e popup_cont-->

<script>

       //s 슬라이드 배너

       /*

       $(document).ready(function() {

               var $status = $('.pagingInfo');

               var $slickElement = $('.popup_slider');

               $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {

                 //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)

                 if(!slick.$dots){

                       return;

                 }

                 var i = (currentSlide ? currentSlide : 0) + 1;

                 $status.text(i + ' / ' + (slick.$dots[0].children.length));

               });

               $slickElement.slick({

                       dots: true, //도트버튼

                       arrows: false, //좌우버튼

                       infinite: true, //반복롤링

                       autoplay: false, //자동롤링

                       slidesToShow: 1

               });

       });

       */

       //e 슬라이드 배너

  function close_popup_1(){

    appboyBridge.logClick('1');

    appboyBridge.getUser().addToCustomAttributeArray('팝업1일간보지않기_리스트','{{this_campaign}}');

     appboyBridge.requestImmediateDataFlush();

     appboyBridge.closeMessage();

  }

   function close_popup_2(){

    appboyBridge.logClick('1');

    document.location.href="appboy://close";

  }

  function bodyClick(){

    appboyBridge.logClick();

    document.location.href="appboy://close";

  }

       //백그라운드 클릭 시 닫기

       document.addEventListener('click',function(e){

               if(e.target.className.indexOf("bodyFrame") > -1)

               {

                       bodyClick();

               }

       });

</script>

</body>

</html>
