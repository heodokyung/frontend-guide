[이벤트 댓글]
http://localhost:3001/the/pub/event/event-textarea
http://localhost:3001/the/pub/event/event-agree-personal
댓글 적용 페이지
http://localhost:3001/the/pub/event/2604-event/initial-quiz/initial-quiz
http://localhost:3001/the/pub/event/2605-event/brand-store/brand-store
http://localhost:3001/the/pub/event/2607-event/brand-store/brand-store
http://localhost:3001/the/pub/event/2606-event/calvo-tuna/eventComment

댓글 모달 형태
http://localhost:3001/the/pub/mypage/my-comment-view

[스와이프]
  import CustomSwiper from '@/components/common/swiper/CustomSwiper.vue';
  import { SwiperSlide } from 'swiper/vue';
  import imgEventSlide1 from '@/assets/images/event/salefesta/2026/09/img_event_benefit1.png';
  import imgEventSlide2 from '@/assets/images/event/salefesta/2026/09/img_event_benefit2.png';
  import imgEventSlide3 from '@/assets/images/event/salefesta/2026/09/img_event_benefit3.png';

   //=============================
  // Swiper
  //=============================

  const eventBenefitList = [
    { id: 1, img: imgEventSlide1 },
    { id: 2, img: imgEventSlide2 },
    { id: 3, img: imgEventSlide3 },
  ];

  const swiperOptions = {
    slidesPerView: 'auto',
    spaceBetween: 9,
    loop: true,
    pagination: true,
    centeredSlides: true,
    observer: true,
    observeParents: true,
    watchOverflow: true,
  };
  
  <!-- 스와이프 -->
    <article class="swiper__container">
      <CustomSwiper :options="swiperOptions" class="swiper">
        <SwiperSlide v-for="eventItem in eventBenefitList" :key="eventItem.id">
          <article class="card__content">
            <img :src="eventItem.img" alt="이벤트 혜택 안내" class="bg-img" />
          </article>
        </SwiperSlide>
      </CustomSwiper>
    </article>

:deep(.swiper) {
      padding-bottom: 40px !important;
      .swiper-pagination {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0 6px;
        height: 7px;
      }
      .swiper-pagination-bullet {
        width: 7px;
        height: 7px;
        margin: 0 !important;
        border-radius: 50%;
        background: #ddd;
        opacity: 1;
        cursor: pointer;
      }

      .swiper-pagination-bullet-active {
        opacity: 1;
        width: 16px;
        border-radius: 5px;
        background-color: #333;
      }
    }


<article class="event__appdown--wrap">
    <h3>CJ더마켓 APP 다운로드</h3>
    <ul>
        <li class="step_1">
            <strong>문자로 URL 전송</strong>
            <p>아래 버튼을 클릭하여 <br>휴대폰으로 <br>URL을 받으세요.</p>
            <a href="javascript:sendUrlPop()" class="btn__link"><img src="/cjom/event/25_07_event/first_purchase/images/btn_send_url.png" alt="휴대폰으로 url 보내기"></a>
        </li>
        <li class="step_2">
            <strong>QR코드로 다운받기</strong>
            <p>QR코드 인식용 애플리케이션으로 <br>QR코드를 스캔하시면 <br>쉽게 다운받으실 수 있어요.</p>
            <span class="img_qr"><img src="/cjom/event/25_07_event/first_purchase/images/img_down_qr.png" alt="Qr코드"></span>
        </li>
        <li class="step_3">
            <strong>앱 스토어 검색</strong>
            <p>내 스마트폰의 앱스토어 <br>또는 PLAY 스토어에서 <br>CJ THEMARKET을 검색하세요.</p>
            <span class="img_app"><img src="/cjom/event/25_07_event/first_purchase/images/ico_google_play.png" alt="구글플레이"></span>
            <span class="img_app"><img src="/cjom/event/25_07_event/first_purchase/images/ico_apple_store.png" alt="애플스토어"></span>
        </li>
    </ul>
</article>


const videoOptions = ref({
    autoplay: true,
    loop: true,
    muted: true,
    playsinline: true,
    preload: 'metadata',
  });
       <video :poster="brandmenu.image" v-bind="videoOptions">

/* --------------------------
    swiper 스와이프 탭과 스와이프 연동 [단일구조]
-------------------------- */
.new__item--wrap .scroll__wrap { overflow-x: auto; overflow-y: hidden; -webkit-overflow-scrolling: touch; scrollbar-width: none; -ms-overflow-style: none; }
.new__item--wrap .scroll__wrap::-webkit-scrollbar {display: none; }    
.new__item--wrap .new__item--thumb {width: 100%; box-sizing: border-box; padding: 0 16px;}
.new__item--wrap .new__item--thumb .swiper-wrapper {display: flex;}
.new__item--wrap .new__item--thumb .swiper-slide {width:auto; flex-shrink: 0;}
.new__item--wrap .new__item--thumb .btn__scroll {display: flex; padding: 0px 17px; height:33px; justify-content: center; align-items: center; box-sizing: border-box; border-radius: 32px; border: 1px solid #DBDFE1; color: #666; background: #fff; font-size: 13px; line-height: 100%;}
.new__item--wrap .new__item--thumb .btn__scroll.active {background: #131519; color: #FFF;}

<script>
$(document).ready(function() {
    if ($('.new__item--wrap .new__item--thumb').length > 0) {
        const $itemBtn = $('.new__item--thumb .btn__scroll');
        const $scrollWrap = $(".new__item--wrap .scroll__swiper--wrap");
        const navwrap = $(".new__item--wrap .new__item--thumb .swiper-wrapper");

        function calculateWidth() {
            const boxWidth = $scrollWrap.width();
            let wrapWidth = 0;
            
            navwrap.find(".swiper-slide").each(function(){
                wrapWidth += $(this).outerWidth() + 8;
            });
            
            return { boxWidth, wrapWidth: wrapWidth - 1 };
        }

        // 썸네일 swiper
        var thumbSwiper = new Swiper('.new__item--wrap .new__item--thumb', {
            slidesPerView: 'auto',
            spaceBetween: 8,
            observer: true,
            observeParents: true,
            roundLengths: true,
            freeMode: false,
            watchSlidesProgress: true,
            slideToClickedSlide: true
        });

        // 메인 swiper
        var mainSwiper = new Swiper('.new__item--wrap .new__item--list', {
            spaceBetween: 0,
            effect: 'slide',
            speed: 500,
            loop: true, 
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            observer: true,
            observeParents: true,
            on: {
                init: function() {
                    // 초기 비디오 재생
                    var realIndex = this.realIndex;
                    var $activeVideo = $(this.slides).eq(this.activeIndex).find('video');
                    
                    if ($activeVideo.length > 0) {
                        $activeVideo.get(0).play().catch(function(e){ console.log(e) });
                    }

                    // 초기 썸네일 활성화
                    $itemBtn.removeClass('active');
                    $itemBtn.eq(realIndex).addClass('active');
                    scrollToActiveThumb(realIndex);
                },
                slideChange: function() {
                    // loop 모드에서는 realIndex 사용 (중요!)
                    var realIndex = this.realIndex;
                    
                    // 1. 썸네일 연동
                    thumbSwiper.slideTo(realIndex);
                    $itemBtn.removeClass('active');
                    $itemBtn.eq(realIndex).addClass('active');
                    
                    // 2. 썸네일 스크롤 이동
                    setTimeout(function() {
                        scrollToActiveThumb(realIndex);
                    }, 50);

                    // 3. 모든 비디오 일시 정지 및 초기화
                    $('.new__item--list video').each(function() {
                        this.pause();
                        this.currentTime = 0;
                    });

                    // 4. 현재 활성화된 슬라이드의 비디오 재생
                    var $activeVideo = $(this.slides[this.activeIndex]).find('video');

                    if ($activeVideo.length > 0) {
                        var videoDom = $activeVideo.get(0);
                        var playPromise = videoDom.play();
                        if (playPromise !== undefined) {
                            playPromise.catch(function(error) {
                                console.log('Autoplay prevented: ', error);
                            });
                        }
                    }
                }
            }
        });

        // 썸네일 클릭 
        $itemBtn.on('click', function() {
            var index = $(this).closest('.swiper-slide').index();
            // loop 모드에서는 slideToLoop 사용
            mainSwiper.slideToLoop(index);
        });

        // 썸네일 스크롤 함수
        function scrollToActiveThumb(realIndex) {
            var $activeSlide = $('.new__item--thumb .swiper-slide').eq(realIndex);
            
            if($activeSlide.length > 0) {
                var { boxWidth, wrapWidth } = calculateWidth();
                var targetPos = $activeSlide.position();
                var selectTargetPos = targetPos.left + $activeSlide.outerWidth() / 2;
                var pos;
                
                if(selectTargetPos <= boxWidth / 2) {
                    pos = 0;
                } else if(wrapWidth - selectTargetPos <= boxWidth / 2) {
                    pos = wrapWidth - boxWidth;
                } else {
                    pos = targetPos.left - (boxWidth / 2) + ($activeSlide.outerWidth() / 2);
                }
                
                if(wrapWidth > boxWidth) {
                    navwrap.css({
                        "transform": "translate3d(" + (pos * -1) + "px, 0, 0)",
                        "transition-duration": "300ms"
                    });
                } else {
                    navwrap.css({
                        "transform": "translate3d(0px, 0, 0)"
                    });
                }
            }
        }
    }
});
</script>

<article>
    <div class="scroll__wrap">
        <div class="swiper-container new__item--thumb">
            <ul class="inner swiper-wrapper">
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상1</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상2</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상3</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상4</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상5</button>
                </li>
            </ul>
        </div>
    </div>
    <div class="swiper-container new__item--list">
        <ul class="swiper-wrapper">
            <li class="swiper-slide">
                <div class="img-box">
                    <img src="/cjom/mobile/images/temp/@temp_cook.jpg?RS=750x600" alt=""> 
                </div>
            </li>
            <li class="swiper-slide">
                <div class="img-box">
                    <img src="/cjom/mobile/images/temp/@temp_cook.jpg?RS=750x600" alt=""> 
                </div>
            </li>
            <li class="swiper-slide">
                <div class="img-box">
                    <img src="/cjom/mobile/images/temp/@temp_cook.jpg?RS=750x600" alt=""> 
                </div>
            </li>
            <li class="swiper-slide">
                <div class="img-box">
                    <img src="/cjom/mobile/images/temp/@temp_cook.jpg?RS=750x600" alt=""> 
                </div>
            </li>
            <li class="swiper-slide">
                <div class="img-box">
                    <img src="/cjom/mobile/images/temp/@temp_cook.jpg?RS=750x600" alt=""> 
                </div>
            </li>
        </ul>
        <!-- //swiper-wrapper -->
    </div>
</article>

/* --------------------------
    swiper 중첩 구조 탭 + [부모&자식] - 위 CSS는 동일
-------------------------- */

<article>
    <div class="scroll__wrap">
        <div class="swiper-container new__item--thumb">
            <ul class="inner swiper-wrapper">
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상1</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상2</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상3</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상4</button>
                </li>
                <li class="swiper-slide">
                    <button type="button" class="btn__scroll">특별밥상5</button>
                </li>
            </ul>
        </div>
    </div>
    <div class="swiper-container new__item--parents">
        <ul class="swiper-wrapper">
            <li class="swiper-slide">
                <div class="swiper-container new__item--child">
                    <ul class="swiper-wrapper">
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp1.jpg" alt=""> 
                            </div>
                        </li>
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp2.jpg" alt=""> 
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="swiper-slide">
                <div class="swiper-container new__item--child">
                    <ul class="swiper-wrapper">
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp3.jpg" alt=""> 
                            </div>
                        </li>
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp4.jpg" alt=""> 
                            </div>
                        </li>
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp5.jpg" alt=""> 
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="swiper-slide">
                <div class="swiper-container new__item--child">
                    <ul class="swiper-wrapper">
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp6.jpg" alt=""> 
                            </div>
                        </li>
                        <li class="swiper-slide">
                            <div class="img__box">
                                <img src="/cjom/mobile/images/temp/new_temp7.jpg" alt=""> 
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <!-- //swiper-wrapper -->
    </div>
</article>

// 기본
$(document).ready(function() {
    const $itemBtn = $('.new__item--thumb .btn__scroll');
    
    // 썸네일 swiper (탭 역할)
    var thumbSwiper = new Swiper('.new__item--wrap .new__item--thumb', {
        slidesPerView: 'auto',
        spaceBetween: 8,
        observer: true,
        observeParents: true,
        roundLengths: true,
        freeMode: false,
        watchSlidesProgress: true,
        slideToClickedSlide: true
    });
    
    // 자식 swiper 먼저 초기화 (페이징 추가)
    var childSwipers = new Swiper('.new__item--wrap .new__item--child', {
        observer: true,
        observeParents: true,
        roundLengths: true,
        speed: 500,
        spaceBetween: 0,
        slidesPerView: 1,
        allowTouchMove: true,
        nested: true,
        resistanceRatio: 0,
        pagination: {
            el: '.child-pagination',
            clickable: true,
            type: 'bullets' // 'bullets', 'fraction', 'progressbar' 중 선택
        }
    });
    
    // 부모 swiper 초기화
    var mainSwiper = new Swiper('.new__item--wrap .new__item--parents', {
        observer: true,
        observeParents: true,
        roundLengths: true,
        speed: 500,
        spaceBetween: 0,
        allowTouchMove: true,
        resistanceRatio: 0,
        thumbs: {
            swiper: thumbSwiper
        },
        on: {
            slideChange: function() {
                var activeIndex = this.activeIndex;
                
                // 썸네일 활성화
                thumbSwiper.slideTo(activeIndex);
                $itemBtn.removeClass('active');
                $itemBtn.eq(activeIndex).addClass('active');
                
                // 썸네일 스크롤 조정
                scrollToActiveThumb(activeIndex);
            }
        }
    });
    
    // 썸네일 클릭 이벤트
    $itemBtn.on('click', function() {
        var index = $(this).closest('.swiper-slide').index();
        mainSwiper.slideTo(index);
    });
    
    // 썸네일 자동 스크롤 함수
    function scrollToActiveThumb(index) {
        var $scrollWrap = $('.new__item--thumb .scroll__wrap');
        var $activeSlide = $('.new__item--thumb .swiper-slide').eq(index);
        
        if ($activeSlide.length) {
            var scrollLeft = $activeSlide.position().left - ($scrollWrap.width() / 2) + ($activeSlide.width() / 2);
            $scrollWrap.animate({
                scrollLeft: scrollLeft
            }, 300);
        }
    }
    
    // 초기 활성화
    $itemBtn.eq(0).addClass('active');
});

// 스크롤 터치 안되
$('.scroll-menu__wrap').on('touchstart touchmove', function(e) {
    e.stopPropagation();
});


// 탭이 스크롤이 같이 되어야 할
$(document).ready(function() {
    const $itemBtn = $('.new__item--thumb .btn__scroll');
    
    if($('.new__item--wrap .new__item--thumb').length > 0) {   
        const $scrollWrap = $(".new__item--wrap .scroll__wrap");
        const navwrap = $(".new__item--wrap .new__item--thumb .swiper-wrapper");
        
        function calculateWidth() {
            const boxWidth = $scrollWrap.width();
            let wrapWidth = 0;
            
            navwrap.find(".swiper-slide").each(function(){
                wrapWidth += $(this).outerWidth() + 8;
            });
            
            return { boxWidth, wrapWidth: wrapWidth - 1 };
        }
        
        var thumbSwiper = new Swiper('.new__item--wrap .new__item--thumb', {
            slidesPerView: 'auto',
            spaceBetween: 8,
            observer: true,
            observeParents: true,
            roundLengths: true,
            freeMode: false,
            watchSlidesProgress: true,
            slideToClickedSlide: true
        });
        
        var childSwipers = new Swiper('.new__item--wrap .new__item--child', {
            observer: true,
            observeParents: true,
            roundLengths: true,
            speed: 500,
            spaceBetween: 0,
            slidesPerView: 1,
            allowTouchMove: true,
            nested: true,
            resistanceRatio: 0,
            // 특정 요소에서 터치 이벤트 제외 (스와이프 슬라이드 충돌 방)
            // threshold: 10
        });
        
        var mainSwiper = new Swiper('.new__item--wrap .new__item--parents', {
            observer: true,
            observeParents: true,
            roundLengths: true,
            speed: 500,
            spaceBetween: 0,
            allowTouchMove: true,
            resistanceRatio: 0,
            thumbs: {
                swiper: thumbSwiper
            },
            on: {
                slideChange: function() {
                    var activeIndex = this.activeIndex;
                    $itemBtn.removeClass('active');
                    $itemBtn.eq(activeIndex).addClass('active');
                    
                    setTimeout(function() {
                        scrollToActiveThumb();
                    }, 50);
                }
            }
        });
        
        $itemBtn.on('click', function() {
            var index = $(this).closest('.swiper-slide').index();
            mainSwiper.slideTo(index);
        });
        
        function scrollToActiveThumb() {
            var $activeSlide = $('.new__item--thumb .swiper-slide-thumb-active');
            
            if($activeSlide.length > 0) {
                var { boxWidth, wrapWidth } = calculateWidth();
                var targetPos = $activeSlide.position();
                var selectTargetPos = targetPos.left + $activeSlide.outerWidth() / 2;
                var pos;
                
                if(selectTargetPos <= boxWidth / 2) {
                    pos = 0;
                } else if(wrapWidth - selectTargetPos <= boxWidth / 2) {
                    pos = wrapWidth - boxWidth;
                } else {
                    pos = targetPos.left - (boxWidth / 2) + ($activeSlide.outerWidth() / 2);
                }
                
                if(wrapWidth > boxWidth) {
                    navwrap.css({
                        "transform": "translate3d(" + (pos * -1) + "px, 0, 0)",
                        "transition-duration": "300ms"
                    });
                } else {
                    navwrap.css({
                        "transform": "translate3d(0px, 0, 0)"
                    });
                }
            }
        }
        
        $itemBtn.eq(0).addClass('active');
    }
});
/* --------------------------
       토글 스위치 라디오   
-------------------------- */
<div class="toggle-wrap">
    <span class="toggle-label">배틀 시작 알림받기</span>
    <label class="switch">
        <input type="checkbox" id="battleToggle">
        <span class="slider round"></span>
    </label>
</div>
.event__battle--wrap .switch {position: relative; display: inline-block; width: 48px; height: 24px;}
.event__battle--wrap .switch input {display: none;}
.event__battle--wrap .slider {position: absolute; cursor: pointer; background-color: #ccc; border-radius: 24px; top: 0; left: 0; right: 0; bottom: 0; transition: 0.3s;}
.event__battle--wrap .slider:before {position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: #fff; border-radius: 50%; transition: 0.3s;}
.event__battle--wrap input:checked + .slider {background-color: #4caf50;}
.event__battle--wrap input:checked + .slider:before {transform: translateX(24px);}
.event__battle--wrap .toggle-wrap {display: flex; align-items: center; gap: 10px; margin-bottom: 25px;}


--------------------------------------


<!-- 알아두세요 -->
                        <div class="accordion__notice--wrap" data-js="accordion" data-options='{"mode":"slide", "isInitActive": false, "autoFold": false}'>
                            <div data-js="accordion__item">
                                <a href="#" class="accordion__anchor" data-js="accordion__anchor">꼭 확인하세요<span class="accordion__arrow"></span></a>
                                <div data-js="accordion__panel">
                                    <ul class="accordion__notice--list">
                                        <li>CJ임직원만의 복리후생 혜택으로 본 행사의 외부 유출은 금지합니다.</li>
                                        <li>26년 설 선물세트는 1인당 구매 수량을 100개 초과할 수 없습니다.</li>
                                        <li>CJ임직원 본인외 사용 또는 선물 外 다른 목적으로(대리구매, 재판매) 구매 시 인사 조치 될 수 있습니다.</li>
                                        <li>선물세트 2개이상 카페테리아로 구매시, 반올림 정책으로 인해 표기된 차감 포인트와 다를 수 있습니다.</li>
                                        <li>식품,건강,신선 선물세트는 각각 배송 될 수 있습니다.</li>
                                        <li><em class="bold">지인분께서 선물할 상품이 필요하신 경우 임직원 지인 추천을 통해 구매 바랍니다.</em>
                                            <div class="btn__wrap">
                                                <a href="#" class="btn__link">
                                                    <img alt="임직원 지인 추천 바로가기" src="/cjom/event/employee/202511/images/mo/staff/btn_notice_staff.png" />
                                                </a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <!--// 알아두세요 -->




vh 계
<style>
.calcHeight {height: calc(var(--vh, 1vh) * 100);}
</style>

// 하단 고정 버튼
<div class="fixed-menu" data-gatracearea="">        
    <div id="sub-bb-banner"><a href="javascript:;"><span class="blind">기획전 이동</span></a></div>
        <a href="javascript:;" class="bb-close"><span class="blind">배너 닫기</span></a>
    </div>
    <a href="javascript:cj.go.top()" class="fixed-menu__button fixed-menu__top" data-gatracearea="" data-gatraceinfo="{&quot;category&quot;:&quot;공통&quot;,&quot;action&quot;:&quot;공통 - 하단 이동버튼 - TOP 클릭&quot;,&quot;label&quot;:&quot;&quot;}" style="display: inline-block; margin-left: auto;">
        <span class="blind">페이지 최상단으로 이동</span>
    </a>
</div>
<a href="javascript:cj.com.backButton();" class="fixed-menu__button fixed-menu__top fixed-menu__top--single" data-gatracearea="" data-gatraceinfo="{&quot;category&quot;:&quot;공통&quot;,&quot;action&quot;:&quot;공통 - 하단 이동버튼 - 뒤로가기 클릭&quot;,&quot;label&quot;:&quot;&quot;}" style="display: inline-block; margin-left: auto;">
    <span class="blind">뒤로가기</span>
</a>


// JS
<script></script>
function vhCalcFrame() {
  const vhValue = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`);
}
vhCalcFrame();
window.addEventListener('resize', vhCalcFrame);
========

 커스텀 라디오

 document.addEventListener('DOMContentLoaded', function() {
    // 모든 라디오 버튼 선택
    const radioButtons = document.querySelectorAll('.radio__select input[type="radio"]');

    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            // 모든 radio__select에서 is-active 클래스 제거
            document.querySelectorAll('.radio__select').forEach(div => {
            div.classList.remove('is-active');
            });
            
            // 선택된 라디오의 부모 radio__select에 is-active 클래스 추가
            this.closest('.radio__select').classList.add('is-active');
        });
    });
});

// 페이지 로드 시 체크된 라디오가 있으면 클래스 추가
document.addEventListener('DOMContentLoaded', () => {
  const checkedRadio = document.querySelector('.radio__select input[type="radio"]:checked');
  if (checkedRadio) {
    checkedRadio.closest('.radio__select').classList.add('is-active');
  }
});
------------------------

 모바일 높이값 계산\
 스크립트
 function setAppHeight() {
    const height = window.innerHeight - 50;
    document.documentElement.style.setProperty('--app-height', `${height}px`);
  }

  onMounted(() => {
    setAppHeight();
    window.addEventListener('resize', setAppHeight);
  });

  onBeforeUnmount(() => {
    window.removeEventListener('resize', setAppHeight);
  });

CSS
height: var(--app-height);
---------------------  

const el = document. querySelector('.scroll__wrap');
if (el.scrollHeight > el.clientHeight) {
  console.log('세로 스크롤 있음');
}

1. 세로스크롤 체크
const hasVerticalScroll = (element) => {
  return element.scrollHeight > element.clientHeight;
};

2. 가로 스크롤 체크
const hasHorizontalScroll = (element) => {
  return element.scrollWidth > element.clientWidth;
};

3. 스크롤 생김 여부 변화 감지
MutationObserver 또는 ResizeObserver를 이용하면 스크롤 생김/없어짐 실시간 감지도 가능해요.

const resizeObserver = new ResizeObserver(() => {
  hasVerticalScroll.value = el.scrollHeight > el.clientHeight;
});
resizeObserver.observe(el);


// 스와이프 PC 좌우 버튼을 슬라이드 바깥에 적용해야 할 
document.querySelectorAll(".swiper__content--wrap").forEach((wrapElement, index) => {
    new Swiper(wrapElement.querySelector(".swiper1"), {
        slidesPerView: "auto",
        centeredSlides: true,
        spaceBetween: 20,
        speed: 500,
        touchEventsTarget: 'wrapper',
        pagination: {
            el: wrapElement.querySelector(".swiper-pagination"),
            clickable: true,
        },
        navigation: {
            nextEl: wrapElement.querySelector(".swiper-button-next"),
            prevEl: wrapElement.querySelector(".swiper-button-prev"),
        },
    });
});

<div class="swiper__content--wrap">
    <div class="swiper swiper1 col4">
        <ul class="swiper-wrapper">
            <li class="swiper-slide">1</li>
            <li class="swiper-slide">2</li>
        </ul>
        <div class="swiper-pagination"></div>
    </div>
    <!-- 버튼을 Swiper 바깥으로 이동 -->
    <div class="swiper-button-next swiper__item1"></div>
    <div class="swiper-button-prev swiper__item1"></div>
</div>

<div class="swiper__content--wrap">
    <div class="swiper swiper1 col4">
        <ul class="swiper-wrapper">
            <li class="swiper-slide">1</li>
            <li class="swiper-slide">2</li>
        </ul>
        <div class="swiper-pagination"></div>
    </div>
    <!-- 버튼을 Swiper 바깥으로 이동 -->
    <div class="swiper-button-next swiper__item2"></div>
    <div class="swiper-button-prev swiper__item2"></div>
</div>

===========================================
중복 할인쿠폰, 결제혜택 등 메뉴바가 sticky 로 작성될 경우는 더세페 9월을 참고해주시고, scrollFix 사용은 알뜰위크 9월을 참고해 주세요.
===========================================
스와이프 버튼 좌우 스크롤

   <div class="btn__scroll--wrap">
      <div class="swiper btnSwiper">
        <div class="swiper-wrapper">
         <div class="swiper-slide"><button type="button">CJ프레시웨이</button></div>
         <div class="swiper-slide"><button type="button">이즈웰</button></div>
         <div class="swiper-slide"><button type="button">코카콜라</button></div>
         <div class="swiper-slide"><button type="button">제품명제품명</button></div>
         <div class="swiper-slide"><button type="button">CJ프레시웨이</button></div>
         <div class="swiper-slide"><button type="button">이즈웰</button></div>
         <div class="swiper-slide"><button type="button">코카콜라</button></div>
        </div>
      </div>
     
      <!-- 두 번째 그룹 예시 -->
      <div class="swiper btnSwiper">
        <div class="swiper-wrapper">
         <div class="swiper-slide"><button type="button">제품명A</button></div>
         <div class="swiper-slide"><button type="button">제품명B</button></div>
         <div class="swiper-slide"><button type="button">제품명C</button></div>
         <div class="swiper-slide"><button type="button">제품명D</button></div>
        </div>
      </div>
     </div>

       document.querySelectorAll('.btnSwiper').forEach((el) => {
    new Swiper(el, {
      slidesPerView: 'auto',
      spaceBetween: 10,
      freeMode: true,
      grabCursor: true,
    });

    el.addEventListener('click', (e) => {
      if (e.target.tagName.toLowerCase() === 'button') {
        el.querySelectorAll('button').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
      }
    });
  });

===================================================================
function toggleActiveClass() {
    $('.event__cj--sobaba .bedge').addClass('active'); // active 클래스 추가
    setTimeout(() => {
        $('.event__cj--sobaba .bedge').removeClass('active'); // 2초 후 active 클래스 제거
    }, 2000);
}

// 첫 번째 실행 (딜레이 없이 바로 실행)
toggleActiveClass();

// 이후 4초 간격으로 반복 실행
setInterval(toggleActiveClass, 4000);

===========================================================
.event__cj--sobaba .f_bedge {position: absolute; top: 0; width: 643px; left: 50%; transform: translateX(-50%); /* animation: flash 2s linear infinite; */ opacity: 0; animation: fadeOut 1s linear forwards}
.event__cj--sobaba .f_bedge.active {animation: fadeIn 1s linear forwards}
 @keyframes flash {
   0% {
       opacity: 1;
   }
   50% {
       opacity: 0;
   }
   100% {
       opacity: 1;
   }
}
@keyframes fadeIn {
      0% {
          opacity: 0;
      }
      100% {
          opacity: 1;
      }
  }
@keyframes fadeOut {
      0% {
          opacity: 1;
      }
      100% {
          opacity: 0;
      }
  }
function toggleBlink() {
   const $fBedge = $('.event__cj--sobaba .f_bedge');

   // fadeIn 애니메이션 적용
   $fBedge.addClass('active');

   // 1초 후 fadeOut 애니메이션 적용
   setTimeout(() => {
      $fBedge.removeClass('active');
      $fBedge.css('opacity', '0'); // opacity를 0으로 설정하여 fadeOut 효과
   }, 2000); // fadeIn(1초) + 1초 유지 = 2초 후 fadeOut
}

// 첫 실행
toggleBlink();

// 3초마다 반복 (fadeIn 1초 + 1초 유지 + fadeOut 1초)
setInterval(toggleBlink, 3000);
 
===================================================================
IOS 키패드 이슈 
let initialHeight = window.innerHeight;

function handleResize() {
    const currentHeight = window.innerHeight;
    const keyboardHeight = initialHeight - currentHeight; // 키보드의 높이 추정

    if (keyboardHeight > 0) {
        // 키보드가 올라왔을 때
        console.log('Keyboard is up', keyboardHeight);
        // 키보드 높이를 기반으로 모달 콘텐츠의 높이를 동적으로 줄임
        $('#bizJoinPopup .modal__container').css('height', `calc(100vh - ${keyboardHeight}px)`);
    } else {
        // 키보드가 내려갔을 때
        console.log('Keyboard is down');
        // 모달 콘텐츠 높이를 원래대로 복구
        $('#bizJoinPopup .modal__container').css('height', '100vh');
    }
}

// resize 이벤트 리스너
window.addEventListener('resize', handleResize);

// 페이지 로드 후 초기 높이를 저장
initialHeight = window.innerHeight;
====================================================================
$(document).scrollTop(top);
====================================================================
// IOS인지 Window인지 체크 
function devideCheck() {
   if (navigator.userAgent.indexOf('Mac OS X') != -1) {
      document.querySelector('body').classList.add('IOS');
   } 
}
devideCheck();       
====================================================================
모달 경로를 전달할 때
?modal=modal-productFlagInfo 
?modal=bizJoinInfoPopup
=====================================================================
미디어 쿼리
=====================================================================
@media screen and (max-width:320px){

}

=====================================================================
 테마 상품영역으로 이동
=====================================================================
<script>
- 모바일
$(function(){
    $('.btn__product--scroll').on('click', function(){
        var boxTop = $('.cornering-exhibition__product-box').offset().top;
        $('html, body').stop().animate({ scrollTop: boxTop - 49 }, 300);
    });
})

// PC
$(function(){
   $('.btn__product--scroll').on('click', function(){
      var boxTop = $('.theme-category-list-wrap').offset().top;
      $('html, body').stop().animate({ scrollTop: boxTop }, 300);
   });
})
</script>

=====================================================================
이벤트 작업시 참고 버튼
=====================================================================
//설문조사 참여 체크
function goCkUrl(exLink) {
    if ( ! $("#checkAgree").is(':checked') ) {
        alert("개인정보 수집 이용 동의를 하셔야 설문조사 참여가 가능합니다.");
        $("input[name=checkAgree]").focus();
    } else {
   if($("#checkAgreeSub").length > 0){
      if ( ! $("#checkAgreeSub").is(':checked') ) {
                alert("개인정보 취급 위탁 동의를 하셔야 설문조사 참여가 가능합니다.");
                $("input[name=checkAgreeSub]").focus();
            } else {
               if(cjConf.appYn == "Y"){
                    CJONS_PLUGIN.exec("OK_COMMON.goOutLink", null, null, {
                        'url' : exLink
                    });
                }else{
                    window.open(exLink);
                }
            }
   } else {
         if (cjConf.appYn == "Y") {
            CJONS_PLUGIN.exec("OK_COMMON.goOutLink", null, null, {
               'url': exLink
            });
         } else {
            window.open(exLink);
         }
      }
    }
}


<a href="javascript:goOutLink('https://www.youtube.com/watch?v=5-JUVpJwGkI')"><img src="https://www.cjthemarket.com/design/cjom/event/2025/11/img_cont3_mo.jpg" alt="">
</a>

외부 링크시 사용(모바일만<target_blank 사용X)
<a href="javascript:goOutLink('https://www.youtube.com/watch?v=5-JUVpJwGkI')">링크</a>

<button type="button" class="btn" onclick="smsAgree();"><span class="blind">마케팅수신동의(SMS)하고쿠폰받기</span></button>
<button type="button" class="btn" onclick="fn_evntMrktAgree();"><span class="blind">LMS SMS수신동의하기</span></button>
<button type="button" class="btn" onclick="applyAppPush();"><span class="blind">APP수신동의하기</span></button>
<button type="button" class="btn" onclick="fn_evntMrktAgree();"><span class="blind">SMS수신동의하기</span></button>
<button type="button" class="btn" onclick="sendUrlPop();"><span class="blind">모바일APP다운받기</span></button>
<button type="button" class="btn" onclick="downloadCoupon('11015845');"><span class="blind">쿠폰다운로드</span></button>
<button type="button" class="btn" onclick="couponDown();"><span class="blind">쿠폰 한번에 다운받기</span></button>
<button type="button" class="btn" onclick="fn_evntAgreePop('응모하기코드==');"><span class="blind">응모하기</span></button>
<button type="button" class="btn"><span class="blind">쿠폰등록하기</span></button>

<ul class="link-list">
   <li><a href="javascript:;" onclick="invitePrime(this, '0')" data-url="https://www.cjthemarket.com" data-image="https://m.cjthemarket.com/cjom/mobile/images" data-title="친구와 함께 the프라임 가입하고 the 놀라운 혜택 받으세요!">카톡으로 초대하기</a></li>
   <li><a href="javascript:;" onclick="invitePrime(this, '1')" data-url="https://www.cjthemarket.com">초대 URL 공유하기</a></li>
</ul>
<ul>
   <li class="ty01">
      <a href="javascript:;" onclick="invitePrime(this, '0')" data-url="https://m.cjthemarket.com" data-image="https://m.cjthemarket.com/cjom/mobile/images" data-title="친구와 함께 the프라임 가입하고 the 놀라운 혜택 받으세요!">카톡으로 초대하기</a>
   </li>
   <li class="ty02">
      <a href="javascript:;" onclick="invitePrime(this, '1')" data-url="https://m.cjth104644emarket.com">초대 URL 공유하기</a>
   </li>
</ul>

<!-- 제품 링크로 바로 갈 때 PRDCD가 필요. -->
<a href="/pc/prod/prodDetail?prdCd=상품코드"><span class="blind">삼천포 파스타</span></a>
<!-- PC -->
<a href="/pc/prod/prodDetail?prdCd=40149535"><span class="blind">삼천포 파스타</span></a>
<!-- MO -->
<a href="/mo/prod/prodDetail?prdCd=40149535"><span class="blind">삼천포 파스타</span></a>

========================================================
인풋 체크 버튼 비활성
========================================================
document.addEventListener("DOMContentLoaded", function() {
  const inputs = document.querySelectorAll('.input__sns');
  const button = document.querySelector('.btn__wrap button');

  function checkInputs() {
    // 모든 input의 값이 공백 제거 후 존재하는지 확인
    const allFilled = Array.from(inputs).every(input => input.value.trim() !== '');
    button.disabled = !allFilled; // 둘 다 채워졌으면 false → 활성화
  }

  // input 입력 시마다 검사
  inputs.forEach(input => input.addEventListener('input', checkInputs));
});


========================================================
웹: 해더영역 깨질 때
========================================================

   <!-- 해더영역 -->
   <div class="temp__header">
      <script>

         $(function() {
            $('.temp__header').load('/cjom/web/guide/temp_load_header.html');
         });
      </script>
   </div>
   <!-- //해더영역 -->

=====================================================================
카운트 스크립트
=====================================================================
<script>
let countTotal = 0;
// 추가 담기 상품 추가 클릭
$('.modal__cart--layer .quantity-column button').on('click', function(){
   let btnTarget  = $(this).attr('class');l
   let numCount   = $(this).closest('.quantity-column').find('.counting-number__input').val();
   const layerText = $('.modal__cart--layer.open .btn__confirm em');

   if(btnTarget == 'btn-increase') {
      countTotal ++;
      $(this).closest('li').addClass('is-active');
   }

   if(btnTarget == 'btn-reduce') {
      if($(this).parents('li').hasClass('is-active')) { countTotal --; }
      if(numCount <= 0) {
         $(this).closest('li').removeClass('is-active');
      }
   }

   layerText.text(countTotal);
});
</script>

=====================================================================
비디오 아이프레임 (iframse) 영역
=====================================================================
alternate-reverse ease-in-out infinite 1.8s

video {object-fit: cover;
    outline: none;
    border: 0;
    -webkit-mask-image: -webkit-radial-gradient(white, black);
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;}

alternate-reverse


<iframe width="100%" height="100%" src="https://www.youtube.com/embed/vMa_t1coF_A" title="푸드 크로니클: 동글납작한 매력으로 전세계를 매혹시킨 피자" 
frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>

<video class="video"  autoplay loop muted playsinline>
   <source src="/cjom/design/event/2022/06/evt_vegandasida_60g.mp4" type="video/mp4">
</video>

<div class="video__content">
   <video class="video" autoplay loop muted playsinline>
      <source src="/cjom/mobile/images/review/review_combine.mp4" type="video/mp4">
   </video>
</div>

<div data-js="floating" data-options="{'top': 100}">
    <div data-js="floating__target-parent">
        <div class="m_now_event_float" data-js="floating__target">
        </div>
    </div>
</div>

<a href="javascript:void(0)">클릭</a>


=====================================================================
// CSS만으로 토글기능
=====================================================================
.event__t-univers .text__field {top: 24%; line-height: 12vw;}
.hatban-challenge .section1 .h-motion1 {top:52px;left:500px;}
.hatban-challenge .section1 .h-motion1 .mot-img1 {animation:blink-effect 1.5s step-end infinite;}
.hatban-challenge .section1 .h-motion1 .mot-img2 {opacity:0;animation:blink-effect2 1.5s step-end infinite;}
.hatban-challenge .section1 .h-motion2 {top:215px;left:397px;}
.hatban-challenge .section1 .h-motion2 .mot-img1 {animation:blink-effect3 3.75s step-end infinite;}
.hatban-challenge .section1 .h-motion2 .mot-img2 {opacity:0;animation:blink-effect4 3.75s step-end infinite;}
.hatban-challenge .section1 .h-motion2 .mot-img3 {opacity:0;animation:blink-effect5 3.75s step-end infinite;}
@keyframes blink-effect {
   50% {opacity:0;}
}

@keyframes blink-effect2 {
   50% {opacity:1;}
}

동작요소
@keyframes blink-effect3 {
   20% {opacity:0;}
}
@keyfraes blink-effect4 {
   20% {opacity:1;}
   40% {opacity:0;}
}
@keyframes blink-effect5 {
   40% {opacity:1;}
   100% {opacity:0;}
}            

=====================================================================

setTime / clearTime

동작요소
function removeBtn (){
   $('.ai__summary .review__comment .btn__comment').removeClass('is-active')
}

setTime
function removeBtnOn (){
   clearBtn = setTimeout(removeBtn, 2000);
}

function removeBtnOff (){
   clearTimeout(clearBtn);
}

=====================================================================
// 클립보드 복사기능
=====================================================================
<script>
$('.btn__layer--copy').on('click', function(){
   const copyVal = $('.coupon__val').val();

   if( $.trim(copyVal).length <= 0) {return;}

   window.navigator.clipboard.writeText(copyVal).then(() => {
      alert("쿠폰번호가 복사되었습니다.");
   });
})
</script>


// 이미지 롤링
$(document).ready(function(){
   let total = $(".rolling__wrap > img").length;
   let num = 0;
   setInterval( function(){
      $(".rolling__wrap > img").removeClass('is-active')
      $(".rolling__wrap > img").eq(num).addClass('is-active');
      num++;
      if(num == total) {num = 0;}
   } , 1000 );
});

    인풋 필드 키업 스크립트
    // 스탭1단계: 전화번호 입력 필드
    $('.modal.membership__confirm .phone__number').keyup(function (event) {
        event = event || window.event;
        let _val = this.value.trim();
        this.value = autoHypenTel(_val);
    });

    // 버튼 활성화 체크 공통
    $('.modal.membership__confirm .btn__check').keyup(function (event) {
        event = event || window.event;
        let _val = this.value.trim();
        if(_val.length > 0) {
            $(this).parents('.wrapper').find('.btn__confirm').addClass('black');
        } else {
            $(this).parents('.wrapper').find('.btn__confirm').removeClass('black');
        }
    });

    max-length
    function handleOnInput(el, maxlength) {
        if(el.value.length > maxlength)  {
            el.value 
            = el.value.substr(0, maxlength);
        }
    }

// 임직원 구분
console.log(cjConf.cjStfYn);
<script>
function redirectPC() {
  const isStaff = cjConf?.cjStfYn; 
  if (isStaff === 'Y') {
    // 임직원 링크
    window.location.href = 'https://www.cjthemarket.com/pc/giftSet/202509/emp/empProd';
  } else if (isStaff === 'N') {
    // 일반 사용자용
    window.location.href = 'https://cjthemarket.com/pc/giftSet/202509/nor/norEvent';
  } else {
    // 예외 처리
    console.error('cjStfYn 값이 올바르지 않습니다:', isStaff);
  }
}
</script>

<script>
function redirectMO() {
  const isStaff = cjConf?.cjStfYn; 
  if (isStaff === 'Y') {
    // 임직원 링크
    window.location.href = 'https://m.cjthemarket.com/mo/giftSet/202509/emp/empProd';
  } else if (isStaff === 'N') {
    // 일반 사용자용
    window.location.href = 'https://m.cjthemarket.com/mo/giftSet/202509/nor/norEvent';
  } else {
    // 예외 처리
    console.error('cjStfYn 값이 올바르지 않습니다:', isStaff);
  }
}
</script>

<div>
<a href="javascript:void(0)" onclick="redirectMO()">aa</a>
<a href="javascript:void(0)" onclick="redirectPC()">aa</a>
</div>

<!-- ga태깅시 -->
Event Category: 기획전
Event Action: 기획전 - 응모하기_105656 클릭
<a href="" onclick="" data-gatraceinfo='{"category":"공통","action":"공통 - 이벤트_기획전_응모하기 클릭","label":""}'>응모하기</a>

개인정보 동의 팝업 : 기획전 104644 참고

&ntg=#id값

앵커링크 부분 사용하실예정인분들 참고부탁드립니다.
https://m.cjthemarket.com/mo/plan/planView?plnId=105602&ntg=scroll-3

// 맥 분기시
function test() {

  var mac = /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform);

  if (mac) {
    document.getElementById('close').classList.add("left");
  }
}

if (navigator.userAgent.indexOf('Mac OS X') != -1) {
  alert("Mac"); // You can do whatever here
} else {
  alert("Windows"); // You can do whatever here
}

<!-- 체크박스 -->
<div class="checkbox" data-js="checkbox" data-options='{ "firstCheck": false }'>
   <div class="checkbox__input" role="checkbox" data-js="checkbox__input">
       쿠폰 최대할인 적용까지 알림
       <input type="checkbox" class="checkbox__hidden" data-js="checkbox__hidden" tabindex="-1" />
   </div>
</div>

 /* 체크박스 커스텀 시 */
.question__checkbox--wrap {}
.question__checkbox--wrap .checkbox__input[aria-checked=true]:after {background: url(/cjom/design/event/2023/07/ico_check_on_mo.png) no-repeat 50% 50%; background-size: cover;}
.question__checkbox--wrap .checkbox__input:before {border:none; background: url(/cjom/design/event/2023/07/ico_check_off_mo.png) no-repeat 50% 50%; background-size: cover;}

<!-- 체크박스 -->
<div class="checkbox question__checkbox--wrap" data-js="checkbox" data-options='{ "firstCheck": false }'>
    <div class="checkbox__input" role="checkbox" data-js="checkbox__input">
        <input type="checkbox" class="checkbox__hidden" data-js="checkbox__hidden" id="checkAgree" tabindex="-1"  />
        <label for="checkAgree">Checkbox</label>
    </div>
</div>


<div class="coupon-input">             
   <fieldset>
      <legend>쿠폰번호 입력</legend>
      <span class="input-text"><input type="text" name="rdnoCpnNo" placeholder="쿠폰 번호를 입력하세요!" title="쿠폰 번호를 입력하세요" onclick="preLoginCk()"></span>
      <button type="button" class="btn-default-lg" onclick="checkCoupon()"><span>등록</span></button>
   </fieldset>
</div>

<!-- 슬라이드 메뉴 PC -->
<div>
   <a href="#slot_acd" data-accordion="" class="active">꼭 알아두세요<span class="accordion_arrow"></span></a>
   <div id="slot_acd" style="">      
      <ul>
         <li>CJ제일제당 임직원만 참여 가능하며 '이벤트 참여하기' 버튼 누른 고객만 포인트 지급 됩니다.<br>(5만원 이하 포인트 :23년 1월 2주차 일괄 지급 , 10만원 포인트&nbsp; : 제세공과금 입금 확인 후 지급)</li>
         <li>실 결제금액 적립 조건에서 한도 미차감 신제품 (New&amp;Hot) 및 선물세트 / 일부 매입 (가전제품) 상품은 제외됩니다.</li>
         <li>구간대별 중복 지급 불가 합니다. (예 : 70만원 구매시 - 50만원 달성 인정 5만원 지급, 150만원 구매시 - 1백만원 달성 인정 10만원 지급)</li>
         <li>5만원 초과 포인트 지급의 경우 제세공과금(22%)은 당첨자 부담이며, 당사의 협력사를 통한 제세공과금 처리를 위해 당첨되신 고객님께 개인정보를 요청 및 활용하게 됩니다.</li>
         <li>혜택은 타인에게 양도 불가하며, 부정한 방법 또는 비정상적인 접근을 통한 임직원 할인 한도 사용 시 지급이 취소됩니다.</li>
      </ul>         
   </div>
</div>

<!-- 슬라이드 메뉴 MO -->
<article class="payback_accordion" data-js="accordion" data-options='{"mode":"slide", "isInitActive": true, "autoFold": false}'>
    <div data-js="accordion__item">
        <a href="#" data-js="accordion__anchor">꼭 알아두세요<span class="accordion_arrow"></span></a>
        <div data-js="accordion__panel">
            <ul>
            <li>CJ제일제당 임직원만 참여 가능하며 '이벤트 참여하기' 버튼 누른 고객만 포인트 지급 됩니다.<br />(5만원 이하 포인트 :23년 1월 2주차 일괄 지급 , 10만원 포인트 : 제세공과금 입금 확인 후 지급)</li>
            <li>실 결제금액 적립 조건에서 한도 미차감 신제품 (New&Hot) 및 선물세트 / 일부 매입 (가전제품) 상품은 제외됩니다.</li>
            <li>구간대별 중복 지급 불가 합니다. (예 : 70만원 구매시 - 50만원 달성 인정 5만원 지급, 150만원 구매시 - 1백만원 달성 인정 10만원 지급)</li>
            <li>5만원 초과 포인트 지급의 경우 제세공과금(22%)은 당첨자 부담이며, 당사의 협력사를 통한 제세공과금 처리를 위해 당첨되신 고객님께 개인정보를 요청 및 활용하게 됩니다.</li>
            <li>혜택은 타인에게 양도 불가하며, 부정한 방법 또는 비정상적인 접근을 통한 임직원 할인 한도 사용 시 지급이 취소됩니다.</li>
            </ul>
        </div>
    </div>
</article>

<div class="prime__accordion--notice" data-js="accordion" data-options='{"mode":"slide", "isInitActive": false, "autoFold": false}'>
   <div data-js="accordion__item" class="t_center">
      <a href="javascript:void(0)" data-js="accordion__anchor" class="custom__item" >알아두세요!</a>
      <div data-js="accordion__panel">
         <ul class="list__type--wrap circle t_left" data-color="color_666">
            <li>the프라임 1개월 무료체험은 가입이력이 없는 the프라임 최초 가입자에 한하여 ID 당 1회 제공됩니다.</li>
            <li>the프라임 1개월 무료체험 시작 시 무료체험 종료일 후 자동결제에 동의한 것으로 간주합니다.</li>
            <li>the프라임 가입비는 1개월 무료체험 종료일에 자동 결제됩니다.</li>
            <li>the프라임 가입 적립금은 가입비 자동 결제일 다음날 오전 10시에 자동 적립됩니다.</li>
            <li>본 혜택은 당사의 사정에 의해 사전 공지 없이 조기 종료 될 수 있습니다.</li>
         </ul>
      </div>
   </div>
</div>

// 타임특가
   $('.saving-slider__timeSale').slick({
      infinite : true,
      arrows : true,
      autoplay : true,           
      autoplaySpeed : 5000,
      speed : 500,
      pauseOnHover : false,
      prevArrow : "<button type='button' class='slick-prev'>Previous</button>",
      nextArrow : "<button type='button' class='slick-next'>Next</button>",
      draggable : true, 
   });
   

========================================================
swiper 바로 동작
========================================================
on: {
      slideChangeTransitionStart: function () {
         this.params.autoplay.delay = 4000;
      },
     init: function () {
      this.params.autoplay.delay = 0;
      this.autoplay.start();
   }
}

========================================================
앵커 화면 이동
========================================================
&ntg=#id값
앵커링크 부분 사용하실예정인분들 참고부탁드립니다.

https://m.cjthemarket.com/mo/plan/planView?plnId=105602&ntg=scroll-3
예시 #id값만으로 진행하면 gnb에 가리기때문에 위에값을 사용하면 그위치에 도달합니다.
혹시 나중에 작업하시게되면 참고부탁드립니다.

========================================================
유튜브 동영상 설정
========================================================
1) 유튜브 자동재생 및 음소거 (주소뒤에)
?autoplay=1&amp;mute=1

2) 하단 컨트롤러 숨기기
&controls=0
"https://www.youtube.com/embed/ibYD23-dtjo?autoplay=1&mute=1&controls=0"

3)반복재생 
속성값은 loop=1 이지만, playlist도 함께 넣어줘야 동작이 된다
해당 동영상의 id값을 playlist에 또 넣어주어야한다.
"https://www.youtube.com/embed/ibYD23-dtjo?autoplay=1&mute=1&controls=0&loop=1&playlist=ibYD23-dtjo"

========================================================
체크박스 버튼 사용 함수
========================================================

   const btnAgree = $('.terms__wrap .btn-area .btn-default');

   $('.terms__wrap .allcheckFunc').click(function() {
      if($(this).is(":checked")) {
         btnAgree.removeAttr('disabled');
      }
      else {
         btnAgree.attr('disabled', 'disabled');
      }
   });

   $(".terms__wrap .evtAgree_accordion input[type=checkbox]").click(function() {
      var total = $(".terms__wrap .evtAgree_accordion input[type=checkbox]").length;
      var checked = $(".terms__wrap .evtAgree_accordion input[type=checkbox]:checked").length;

      console.log()
      if(total == checked) {btnAgree.removeAttr('disabled');}
      else {btnAgree.attr('disabled', 'disabled');}         
   });

========================================================
 스크롤 시 상단 고정 메뉴 적용
========================================================

document.addEventListener('DOMContentLoaded', function() {
    
    const timeInfoWrap = document.querySelector('.time__info--wrap');
    const themeCategoryWrap = document.querySelector('.cornering-exhibition__product-box');
    const header = document.querySelector('#header');
    const product00 = document.querySelector('.product_00');
    
    let ticking = false;
    
    function handleScroll() {
        const curPos = window.pageYOffset;
        
        // header + product_00 높이 기준으로 fixed 적용
        const headerHeight = header ? header.offsetHeight : 0;
        const product00Height = product00 ? product00.offsetHeight : 0;
        const visuH = headerHeight + product00Height + 1;
        
        if (curPos > visuH) {
            let headerHeight = header.outerHeight();
            timeInfoWrap.classList.add('fixed').style.top(headerHeight);
        } else {
            timeInfoWrap.classList.remove('fixed');
        }
        
        // 표시/숨김 로직
        let shouldHide = false;                        
        if (themeCategoryWrap && !shouldHide) {
            const themeCategoryTop = themeCategoryWrap.getBoundingClientRect().top + curPos;
            const offset = 150;
            if (curPos >= (themeCategoryTop - offset)) {
                shouldHide = true;
            }
        }
        
        timeInfoWrap.style.display = shouldHide ? 'none' : 'block';
        
        ticking = false;
    }
    
    window.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(handleScroll);
            ticking = true;
        }
    });
    
    handleScroll();
});

========================================================
 기획전에 장바구니가 들어가는 경우
========================================================
<button type="button" class="btn__cart" onclick="addToCartNew(this);" data-prdcd="40112299" data-ctgrid="" data-plnid="603737" data-giftsetevntid="" data-slpkprdcd="" data-prdqtylist="" data-cartprdptn="" data-dlvdt="" data-prdnm="[세뚜]쁘띠첼 미초 석류 900ml">
<span class="blind">장바구니 담기</span>
</button>

========================================================
스크롤 이동
========================================================
<script>
$(function(){
   function brandScrollMove () {
      window.scrollTo(0, 0);
      const headerH = $('#header').outerHeight();
      const elementOffsetTop = $('.renewal__bibigo').offset().top - headerH;
      // window.scrollTo({ top: elementOffsetTop, behavior: 'smooth' });
      // $('html, body').scrollTop({elementOffsetTop}, 400);
      $('html, body').stop().animate({scrollTop: elementOffsetTop}, 400);
   }
   // brandScrollMove();
});



$(window).scroll(function(){
    let curPos = $(window).scrollTop();
    let navHidePos = 0;

    if(navHidePos.length > 0) {
        navHidePos  = $('.cornering-exhibition__product-box').offset().top;
        if (curPos < navHidePos) $(".top_tab_wrap").show();
        else $(".top_tab_wrap").hide();
    }

    var visuH = $(".header").height() +  $('.evt-cont00').height() + 1;
    if($(this).scrollTop() > visuH ) {
        $(".top_tab_wrap").addClass('fixed');
    } else {
        $(".top_tab_wrap").removeClass('fixed');
    }

    console.log(curPos)
});

</script>

========================================================
// 팝업 호출 함수
========================================================
<script>
let modalToast = {
   open(){ // 모달 팝업 호출
      $('.modal__toast--layer').addClass('is-active');
      $('html, body').css({'overflow':'hidden'});
   },
   close(){ // 모달 팝업 닫기
      $('.modal__toast--layer').removeClass('is-active');
      $('html, body').css({'overflow':'auto'});
   }
}
</script>

========================================================
// 스크롤 잠금
========================================================
<script>
const enableScrollLock = () => {
   const { body } = document;

   if (!body.getAttribute('scrollY')) {
      const pageY = window.pageYOffset;

      body.setAttribute('scrollY', pageY.toString());

      body.style.overflow = 'hidden';
      body.style.position = 'fixed';
      body.style.left = '0px';
      body.style.right = '0px';
      body.style.bottom = '0px';
      body.style.top = `-${pageY}px`;
   }
};
</script>

========================================================
// 스크롤 잠금 해제
========================================================
<script>
const disableScrollLock = () => {
   const { body } = document;

   if (body.getAttribute('scrollY')) {
      body.style.removeProperty('overflow');
      body.style.removeProperty('position');
      body.style.removeProperty('top');
      body.style.removeProperty('left');
      body.style.removeProperty('right');
      body.style.removeProperty('bottom');

      window.scrollTo(0, Number(body.getAttribute('scrollY')));

      body.removeAttribute('scrollY');
   }
};

 // 팝업 호출 함수
let modalToast = {
   open(){ // 모달 팝업 호출
      $('.themarket__popup--wrap').show();
      enableScrollLock()
   },
   close(){ // 모달 팝업 닫기
      $('.themarket__popup--wrap').hide();
      disableScrollLock();
  }
}
</script>

========================================================

키 프레임 CSS
@keyframes sprite {
    to { background-position:100% 0;}
  }

@-webkit-keyframes sprite {
    to { background-position:100% 0;}
}

-webkit-animation:sprite 0.45s steps(3) forwards; animation:sprite 0.45s steps(3) infinite;


.evt-obj1{top:0;left:0;width:100%;height:100%;background-position:0 0;background-repeat:no-repeat;animation:blink-effect 3s step-end infinite;}
@keyframes blink-effect{
    0%{background-image:url(https://www.cjthemarket.com/cjom/design/event/2024/04/evt_blackday_1_1_pc.jpg);}
    50%{background-image:url(https://www.cjthemarket.com/cjom/design/event/2024/04/evt_blackday_1_2_pc.jpg);}
}

이동

.event__morning-market .animate__item {position:absolute; z-index:2; width: 88vw; height:12vw; top:9.5%; background: url(/cjom/event/25_06_event/morning_market/images/img_ani_obj_m.png) no-repeat 0 0; background-size: contain;
   transform: translateX(-101%);
   animation-name: moveObj;
   animation-duration: 6s;
   animation-timing-function : linear;
   animation-iteration-count :infinite;
}

@keyframes translateX {
    0% {transform: translateX(70%);}
    100% {transform: translateX(-101%);}
}

========================================================
꽃 떨어지는 모션
========================================================
<link rel="stylesheet" href="/cjom/mobile/css/flower.css" />
예시 :
https://qas.cjthemarket.com/cjom/mobile/html/TM-SB-M.MAIN-001.html


========================================================
// 툴팁
========================================================
<div class="order-regular__delivery-date-q-box">
    <span class="order-regular__delivery-date-q">출고일이란?</span>
    <div class="tooltip" data-js="tooltip">
        <button class="tooltip__anchore" data-js="tooltip__button">
            <span class="blind">출고일이란?</span>
        </button>
        <div class="tooltip__pannel tooltip__pannel--right"
            data-js="tooltip__panel">
            <div class="tooltip__text">
                상품이 준비되기 시작하는 날짜입니다.
                <a href="#" class="cart-prime-tooltip__close btn--ico07" data-js="tooltip__button"><span class="blind">툴팁닫기</span></a>
            </div>
        </div>
    </div>
</div>


    <div class="tooltip">
        <button class="tooltip__anchore"  data-js="tooltip__button">
            <span class="blind">tooltip</span>
        </button>
        <div class="tooltip__pannel">
            <div class="tooltip__text">
                2004년 부터 부가가치세법의 변경에 따라 세금계산서와 영수증(신용카드)은
                이중 발행이 불가하오니 신중하게 선택하여 신청하시기 바랍니다.
                (부가세법 시행령 57조 2항)이에 신용카드로 결제시, 세금계산서 발급 요청이 전혀 불가합니다.
            </div>
        </div>
    </div>


ios andrid 구분
   



========================================================
// 슬릭 슬라이더 옵션
========================================================
<script>
   $(function(){
      $('.slider-wrap').slick({
      slide: 'div',        //슬라이드 되어야 할 태그
      infinite : true,     //무한 반복 옵션
      slidesToShow : 1,        // 한 화면에 보여질 컨텐츠 개수
      slidesToScroll : 1,        //스크롤 한번에 움직일 컨텐츠 개수
      speed : 500,     // 다음 버튼 누르고 다음 화면 뜨는데까지 걸리는 시간(ms)
      arrows : true,         // 옆으로 이동하는 화살표 표시 여부
      dots : true,         // 스크롤바 아래 점으로 페이지네이션 여부
      autoplay : true,            // 자동 스크롤 사용 여부
      autoplaySpeed : 2000,         // 자동 스크롤 시 다음으로 넘어가는데 걸리는 시간 (ms)
      pauseOnHover : true,        // 슬라이드 이동    시 마우스 호버하면 슬라이더 멈추게 설정
      vertical : false,        // 세로 방향 슬라이드 옵션
      prevArrow : "<button type='button' class='slick-prev'>Previous</button>",
      nextArrow : "<button type='button' class='slick-next'>Next</button>",
      draggable : true,     //드래그 가능 여부
      responsive: [ // 반응형 웹 구현 옵션
         {
         breakpoint: 960, //화면 사이즈 960px
         settings: {
            slidesToShow: 4
         }
         },
         {
         breakpoint: 768, //화면 사이즈 768px
         settings: {
            slidesToShow: 5
         }
         }
      ]

      });
   })
</script>

.slick-slider .slick-list{
    -webkit-transform: translate3d(0, 0, 0);
    -moz-transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
    -o-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
    transition-delay: 10ms;
}


<!-- 이벤트 슬릭 슬라이드 MO -->
 /* Slider */
        [data-js="slick__track"] {overflow: hidden;}
        .slick-slider {position: relative; display: block; box-sizing: border-box; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; -webkit-touch-callout: none; -khtml-user-select: none; -ms-touch-action: pan-y; touch-action: pan-y; -webkit-tap-highlight-color: transparent; opacity: 0; -webkit-transition: all 0.3s; -moz-transition: all 0.3s; transition: all 0.3s;}
        .slick-initialized {opacity: 1;}
        .slick-list {position: relative; display: block; overflow: hidden; margin: 0; padding: 0;}
        .slick-list:focus {outline: none;}
        .slick-list.dragging {cursor: pointer; cursor: hand;}
        .slick-slider .slick-track,
        .slick-slider .slick-list { -webkit-transform: translate3d(0, 0, 0); -moz-transform: translate3d(0, 0, 0); -ms-transform: translate3d(0, 0, 0); -o-transform: translate3d(0, 0, 0); transform: translate3d(0, 0, 0);}
        .slick-track {position: relative; top: 0; left: 0; display: block; margin-left: auto; margin-right: auto;}
        .slick-track:before,
        .slick-track:after {display: table; content: '';}
        .slick-track:after {clear: both;}
        .slick-loading .slick-track {visibility: hidden;}
        .slick-slide,
        .main__visual-item {float: left; height: 100%; min-height: 1px;}
        [dir='rtl'] .slick-slide {float: right;}
        .slick-slide img {display: block;}
        .slick-slide.slick-loading img {display: none;}
        .slick-slide.dragging img {pointer-events: none;}
        .slick-initialized .slick-slide,
        .slick-initialized .main__visual-item
        .slick-initialized *[data-js=slick__item] {display: block;}
        .slick-loading .slick-slide {visibility: hidden;}
        .slick-vertical .slick-slide {display: block; height: auto; border: 1px solid transparent;}
        .slick-arrow.slick-hidden {display: none;}
        .slick-for {text-align: center;}
        .slick-nav {text-align: center;}
        .slick-slide a {position: relative; outline-offset: -2px;}
        .slick-with-video .slick-track {display: flex; align-items: center;}
        .slick-with-video .slick-slide {float: none;}
        /* //Slider */


=====================================================================
가이드 컴포넌트 스크립트(모바일)
https://publishq.cjthemarket.com/cjom/mobile/html/guide-script.html

img.cjthemarket.com

=====================================================================
작업 참고 URL
=====================================================================
스크롤 탭 메뉴 활성화
http://127.0.0.1:5500/cjom/event/22_06_event/bibigo_kimchi_p_06.html

슬라이드 토글 안내 메뉴 참고
http://127.0.0.1:5500/cjom/event/22_07_event/bbq_07.html
http://127.0.0.1:5500/cjom/event/22_02_event/bibigo_newbegin_pc_0223.html

체크박스(녹색)
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.EXH-008-lgu.html


쿠폰번호
PC - https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.EXH-9-lgu.html
MO - https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.EXH-008-lgu.html


UI 모바일 작업 : 동영상, 상풍 좌우 스크롤
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-007_01.html
영상 자막 +, 스와이프 드래그
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PLY-002.html#

하단 스티키 메뉴
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-007_03.html
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-007_04.html
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-007_05.html

하단 테이블 표 정보
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-016.html
http://127.0.0.1:5500/cjom/mobile/html/TM-SB-M.PRO-017.html

가로 그래프
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRO-018_01.html

로딩 참고
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.SUB-BEST02.html

브랜딩 교차
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.BRD-003.html

현금영수증 신청
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.PRM-005.html

체크박스 변형, 해시태그 영역
https://publishq.cjthemarket.com/cjom/mobile/html/TM-SB-M.HLT-003.html?modal=modal
https://www.cjthemarket.com/pc/plan/planView?plnId=104767

장바구니 담기, 하단 갯수 팝업
http://10.184.181.139:5500/cjom/mobile/html/prd_detail_sample01.html#

탭(4)
http://10.184.181.139:5500/cjom/mobile/html/TM-SB-M.COU-010.html

모바일 스크롤링 상단 탑메뉴 고정(3)
http://127.0.0.1:5500/cjom/mobile/html/TM-SB-M.EXH-002_ver2_03.html

검색 참고
TM-SB-M.SRC-010_01

공유하기 팝업
https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.PRO-011.html?modal=detailSharePop

주소 검색 팝업
https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.ORD-102.html?modal=deliveryList

스크롤 팝업
https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.ORD-111.html?modal=interestFreeGuidePop

상품목록, 로딩이미지
https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.CNR-003_2.html
https://publishq.cjthemarket.com/cjom/web/html/TM-SB-P.MAIN-Pilot_01.html
=====================================================================

// tab pc
jQuery.fn.extend({
    menuScroll: function(offset) {
        // Declare all global variables
        var topMenu = this;
        var topOffset = 70 + offset; // 70 + h
        var menuItems = $(topMenu).find("a");
        var lastId;

        // Save all menu items into scrollItems array
        var scrollItems = $(menuItems).map(function() {
            var item = $($(this).attr("href"));
            if (item.length) {
                return item;
            }
        });

        // When the menu item is clicked, get the #id from the href value, then scroll to the #id element
        $(topMenu).on("click", "a", function(e){
            e.preventDefault();
            var href = $(this).attr("href");
            var tabH = $('.top_tab_wrap .sticky').outerHeight();
            var topOffset = 0;
            if($("#header").hasClass("is-fixed")){
                topOffset = 70;
            }else{
                topOffset = 160;
            };

            var calc = tabH + topOffset;
            var targetOffset = $(href).offset().top;
            var offsetTop = href === "#" ? 0 : targetOffset - calc;

            $('html, body').stop().animate({ scrollTop: offsetTop + 2 }, 300);
        });

        // When page is scrolled
        $(window).scroll(function(){
            var nm = $("html").scrollTop();
            var nw = $("body").scrollTop();
            var fromTop = (nm > nw ? nm : nw)+topOffset;
            var current = $(scrollItems).map(function(){
                if ($(this).offset().top <= fromTop)
                return this;
            });

            current = current[current.length-1];
            var id = current && current.length ? current[0].id : "";

            if (lastId !== id) {
                lastId = id;

                $('.top_tab_wrap .nav li').removeClass('none');

                $(menuItems)
                .parent().removeClass("active")
                .end().filter("[href='#"+id+"']").parent().addClass("active").siblings().addClass('none')
                ;
            }

            if(lastId == undefined) {
                $('.top_tab_wrap .nav li').attr('class', '')
            }
        });
    }
});
=====================================================================
// tab mo
jQuery.fn.extend({
    menuScroll: function(offset) {
        // Declare all global variables
        var topMenu = this;
        var menuItems = $(topMenu).find("a");
        var lastId;

        // Save all menu items into scrollItems array
        var scrollItems = $(menuItems).map(function() {
            var item = $($(this).attr("href"));
            if (item.length) {
                return item;
            }
        });


        $(topMenu).on("click", "a", function(e){
            var href = $(this).attr("href");
            var subTIt = $(this).parents('#contents').find('.section__title-box');
            var tabNavHeight = $(".top_tab_wrap .nav").height();
            var idx = $(this).parent().index();
            // if(idx == 2){
            //  swiperPrt.slideTo(1, 700) 20231020 수정
            // };
            //
            //var topOffset = subTIt.height() + $(this).height(); //default
            var topOffset = subTIt.height() + tabNavHeight;
            var offsetTop = href === "#" ? 0 : $(href).offset().top - topOffset;
            $('html, body').stop().animate({ scrollTop: offsetTop+1 }, 300);

            e.preventDefault();
        });

        // When page is scrolled
        $(window).scroll(function(){
            var nm = $("html").scrollTop();
            var nw = $("body").scrollTop();
            var topOffset = $('#contents').find('.section__title-box').height() + $(".top_tab_wrap .nav").height() + 5;
            var fromTop = (nm > nw ? nm : nw)+ topOffset;

            // When the page pass one #id section, return all passed sections to scrollItems and save them into new array current
            var current = $(scrollItems).map(function(){
                if ($(this).offset().top <= fromTop)
                return this;
            });

            // Get the most recent passed section from current array
            current = current[current.length-1];
            var id = current && current.length ? current[0].id : "";
            if (lastId !== id) {
                lastId = id;
                // Set/remove active class

                $('.top_tab_wrap .nav li').removeClass('none');

                $(menuItems)
                .parent().removeClass("active")
                .end().filter("[href='#"+id+"']").parent().addClass("active").siblings().addClass('none');
            }

            if(lastId == undefined) {
                $('.top_tab_wrap .nav li').attr('class', '')
            }
        });
    }
});


=====
눈내림 효과
=====

document.addEventListener('DOMContentLoaded', function () {
  const snowContainer = document.querySelector('.event-cont.visual .snow-wrap');
  if (!snowContainer) return;

  const snowCount = 40; // 눈송이 개수 조절  
  const frag = document.createDocumentFragment();

  for (let i = 0; i < snowCount; i++) {
    const snow = document.createElement('div');
    snow.classList.add('snowflake');

    // 모양: 
    snow.textContent = '❄'; // 또는 '●❄'로

    // 좌우 시작 위치 (vw 단위)
    const left = Math.random() * 100;
    snow.style.left = left + 'vw';

    // 크기 클래스 임의 적용
    const sizeRand = Math.random();
    if (sizeRand < 0.4) snow.classList.add('small');
    else if (sizeRand < 0.8) snow.classList.add('medium');
    else snow.classList.add('large');

    // 애니메이션 지속시간 및 딜레이 랜덤화
    const duration = 6 + Math.random() * 8; // 6 ~ 14s
    const delay = Math.random() * 5;        // 0 ~ 5s
    snow.style.animationDuration = duration + 's';
    snow.style.animationDelay = delay + 's';

    // 좌우 흔들림 (낙하 중 X 이동값)
    const xMove = (Math.random() * 80 - 40); // -40px ~ +40px
    snow.style.setProperty('--xmove', xMove + 'px');

    // 약간의 초기 위치 랜덤 (음수로 시작해 자연스럽게 등장)
    const startTop = -(Math.random() * 20 + 5); // -5vh ~ -25vh
    snow.style.top = startTop + 'vh';

    frag.appendChild(snow);
  }

  snowContainer.appendChild(frag);
});